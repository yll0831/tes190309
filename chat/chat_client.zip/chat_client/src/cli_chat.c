#include <stdio.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <string.h>
#include <stdlib.h>
#include "Double_Link.h"
#include "cli_chat.h"
#include "unistd.h"


#define  PORT  10086            //服务器的端口号 
#define  IP "192.168.10.221"    //服务器的IP地址  
#define  SENDBUFSIZE 60         //最大发送缓冲区大小
#define  RECBUFSIZE 60          //最大接收缓冲区大小
#define  CLIFDBUFSIZE 10        //套套接字fd的缓冲区大小
#define  NEWCLILABELSIZE 6      //新用户标识符缓冲区大小

int curCliSocketFd;     //当前客户端sockketFd
char recBuf[RECBUFSIZE] = {0};  //发送缓冲区
char sendBuf[SENDBUFSIZE] = {0};    

NODE curCliNode,cliNode;    //当前用户节点,临时结点

int svrSocketFd;    //服务端socketfd
int dLinkSize;      //暂存双向链表表节点个数

void * tha_fun(void * arg)
{
    char cliFdBuf[CLIFDBUFSIZE + 1] = {0};  //用户标识符缓冲区
    int ret;
    char cliSocketFd,i = 0; //
    NODE * nodePtr; //节点指针
    while(1)
    {
        memset(recBuf,0,RECBUFSIZE);
        ret = recv((int)arg,recBuf,RECBUFSIZE,MSG_DONTWAIT);    //非阻塞接收数据
        if(ret > 0)
        {   
            if((strncmp(recBuf,"newcli",NEWCLILABELSIZE) == 0))  //有新上线用户
            {
                //获取用户socketFd
                memset(cliFdBuf,0,sizeof(cliFdBuf));
                strncpy(cliFdBuf,recBuf + NEWCLILABELSIZE,CLIFDBUFSIZE);
                cliNode.cliSocketFd = atoi(cliFdBuf);

                //获取用户名
                strcpy(cliNode.userName,recBuf + NEWCLILABELSIZE + CLIFDBUFSIZE);

                /* 新建节点，成功：返回节点指针，失败：返回NULL */
                nodePtr =  Create_Node(&cliNode);
                if(nodePtr == NULL)
                {
                    printf("--CLIENT--:%s:Create_Node error!\n",__func__);
                    return ;
                }

                /* 将新节点插入链表末尾 */
                Dlink_Insert_Last(nodePtr);

                Display_Online_User();  //显示所有在线用户
                printf("--CLIENT--:%s:New users are coming online,Please select a chat object:\n",curCliNode.userName);
            }
            else    //接收消息
            {
                //获取发送方套接字fd
                memset(cliFdBuf,0,CLIFDBUFSIZE + 1);
                strncpy(cliFdBuf,recBuf,CLIFDBUFSIZE);
                cliSocketFd = atoi(cliFdBuf);

                //打印接收到的消息
                nodePtr = Get_First_Node();
                dLinkSize = Dling_Size();
                i = 0;
                while(i < dLinkSize)
                {
                    if(nodePtr->cliSocketFd == cliSocketFd)
                    {
                        printf("--CLIENT--:receive from %s:\n%s\n",nodePtr->userName,recBuf + CLIFDBUFSIZE);
                        break;
                    }
                    nodePtr = nodePtr->next;
                    i++;
                }
                if(i == dLinkSize)
                {
                    printf("--CLIENT--:There is no such cliSocketFd %d in the DLink!\n",cliSocketFd);
                }
            }
            
        }
    }
}

int main()
{
	ssize_t  ret;
	socklen_t  svrAddrLength;  // struct socksvrAddr_in 类型的长度
	struct  sockaddr_in svrAddr;
   
    int multiUse;   //计数
    NODE * nodePtr;

    pthread_t thaId;    
	
	//创建socket套接字 
	svrSocketFd = socket(AF_INET, SOCK_STREAM ,0 );
	if(svrSocketFd < 0)
	{
		printf("--CLIENT--:%s:scoket is error\n",__func__);
		return -1;
	}

	svrAddrLength = sizeof(svrAddr);
	memset(&svrAddr,0,sizeof(svrAddr));
	//填入服务器IP和端口
	svrAddr.sin_family = AF_INET;
	svrAddr.sin_port = htons(PORT);
	svrAddr.sin_addr.s_addr = inet_addr(IP);
	
	//请求连接到服务器
	ret = connect(svrSocketFd,(struct sockaddr *)&svrAddr,svrAddrLength);
	if(ret < 0)
	{
		printf("--CLIENT--:%s:connect is error\n",__func__);
		return -1;
	}
    
    //初始化本客户端
    ret = Init_Client();
    if(ret < 0)
    {
        printf("--CLIENT--:Init_Client error!\n");
        return -1;
    }
    

    
    //创建线程
    ret = pthread_create(&thaId,NULL,tha_fun,(void *)svrSocketFd);
    if(ret < 0)
    {
        printf("--CLIENT--:pthread_create error!\n");
        return -1;
    }
    ret = pthread_detach(thaId);
    if(ret != 0)
    {
        printf("--CLIENT--:pthread_detach error!\n");
    }

    Display_Online_User();  
    while(1)
    {
        dLinkSize = Dling_Size();
        if(dLinkSize)
        {
            memset(sendBuf,0,SENDBUFSIZE);
            while(1)
            {
                //获取目标用户
                printf("--CLIENT--:%s:Please select a chat object:\n",curCliNode.userName);
                scanf("%s",sendBuf);
                multiUse = 0;
                
                nodePtr = Get_First_Node();
                while(multiUse < dLinkSize)
                {
                    if(strcmp(sendBuf,nodePtr->userName) == 0)
                    {
                        sprintf(sendBuf,"%d",nodePtr->cliSocketFd); //写入目标用户fd
                        break;
                    }
                    nodePtr = nodePtr->next;
                    multiUse++;
                }
                if(multiUse != dLinkSize )
                {
                    break;
                }
            }

            //获取发送内容
            printf("--CLIENT--:%s:Please enter the message you want to send:\n",curCliNode.userName);
            scanf("%s",sendBuf + CLIFDBUFSIZE);
            
            //发送消息到服务器
            ret = send(svrSocketFd,sendBuf,CLIFDBUFSIZE + strlen(sendBuf + CLIFDBUFSIZE) + 1,0);
            if(ret < 0)
            {
                printf("--CLIENT--:%s：Fail to send\n",curCliNode.userName);
                return -1;
            }
            
            printf("--CLIENT--:%s:send successfully\n",curCliNode.userName);
        }
    }
	
	//close(svrFd);
	
	return 0;
}

//初始化客户端
int Init_Client(void)
{
    int ret;
    NODE * nodePtr;
    char buf[50] = {0};

    gethostname(buf,sizeof(buf));
    fprintf(stdout,"--CLIENT--:HOST_NAME:%s\n",buf);   //打印本客户端主机名

    //* 新建双向链表，成功：返回 0，失败：返回 -1 */
    ret = Create_Dlink();
    if(ret != 0)
    {
        printf("--CLIENT--:create double link error!\n");
        return -1;
    }

    //获取本客户端用户名
    printf("Please enter your user name:\n");
    memset(curCliNode.userName,0,USERNAMESIZE);
    scanf("%s",curCliNode.userName);

    //发送用户名到服务器
    memset(sendBuf,0,SENDBUFSIZE);
    sprintf(sendBuf,"userName%s",curCliNode.userName);
    ret = send(svrSocketFd,sendBuf,strlen(sendBuf) + 1,0);
    if(ret < 0)
    {
        printf("--CLIENT--:send is error\n");
        return -1;
    }

    //接收服务器发过来的本服务器的socketFd
    while(1)    
    {
        memset(recBuf,0,RECBUFSIZE);
        ret = recv(svrSocketFd,recBuf,RECBUFSIZE,0);    //MSG_DONTWAIT
        if(ret > 0)
        {
            if(strncmp(recBuf,"cliId",5) == 0)
            {
                curCliNode.cliSocketFd = atoi(recBuf + 5);
                break;
            }
            else
            {
                printf("--CLIENT--:Failed to accept current client socket fd!\n");
                return -1;
            } 
        }
    }
    
   
    //接收当前在线用户的信息
    while(1)
    {
        memset(recBuf,0,RECBUFSIZE);
        ret = recv(svrSocketFd,recBuf,RECBUFSIZE,MSG_DONTWAIT);    
        if(ret > 0)
        { 
            if(strncmp(recBuf,"newcli",NEWCLILABELSIZE) == 0)
            {
                memset(buf,0,sizeof(buf));
                strncpy(buf,recBuf + NEWCLILABELSIZE,CLIFDBUFSIZE); //获取用户fd
                cliNode.cliSocketFd = atoi(buf);
                strcpy(cliNode.userName,recBuf + NEWCLILABELSIZE + CLIFDBUFSIZE);   //获取用户名

                /* 新建节点，成功：返回节点指针，失败：返回NULL */
                nodePtr =  Create_Node(&cliNode);
                if(nodePtr == NULL)
                {
                    printf("--CLIENT--:Create_Node error!\n");
                    return -1;
                }

                /* 将新节点插入链表末尾 */
                Dlink_Insert_Last(nodePtr);
            }
            else if(strncmp(recBuf,"end",3) == 0) //获取在线用户信息完毕，打印在线用户信息
            {
                break;
            }
        }
    }
}

void Display_Online_User(void)
{
    int i = 0;
    NODE * nodePtr;
    dLinkSize = Dling_Size();
    if(dLinkSize)
    {   
        printf("----------NUMBER OF ONLINE PEOPLE:%2d----------\n",dLinkSize + 1);
        nodePtr = Get_First_Node();
        while(i++ < dLinkSize)
        {
            //printf("%d.cliSocketFd:%5d | username:%s\n",i,no-ePtr->cliSocketFd,nodePtr->userName);
            printf("%d.%s\n",i,nodePtr->userName);
            nodePtr = nodePtr->next; 
        }
        printf("-----------------------------------------------\n");
        
    }
    else 
    {
        printf("NUMBER OF ONLINE PEOPLE:%2d\n",1);
    }
}