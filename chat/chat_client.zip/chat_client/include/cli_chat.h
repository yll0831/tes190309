#ifndef CLI_CHAT_H
#define CLI_CHAT_H



void Display_Online_User(void);
int Init_Client(void);










#endif